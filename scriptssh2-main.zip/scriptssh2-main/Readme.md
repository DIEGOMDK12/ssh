# PROJETO DESCONTINUADO SEM SUPORTE


# Atualizar Pacotes do Sistema
```
apt-get update -y; apt-get upgrade -y
```

# instalador Scriptssh 
```
bash <(wget -qO- raw.githubusercontent.com/CoutyCT/scriptssh2/main/Plus)
```

# Definir/Alterar senha root
```
bash <(wget -qO- raw.githubusercontent.com/DIEGOMDK12/ssh.git/senharoot.ssh)
```
![logo](https://github.com/DIEGOMDK12/DIEGOMDK12/blob/ssh.git/imagens/menu1.PNG)
![logo](https://github.com/DIEGOMDK12/DIEGOMDK12/blob/ssh.git/imagens/menu2.PNG)
